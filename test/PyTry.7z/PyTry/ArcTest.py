from shutil import copyfile as c
c('ChatUI_HouseOfPytry.ent','ChatUI_HouseOfPytry.tar')
c('ChatUI_HouseOfPytry.ent','ChatUI_HouseOfPytry.tgz')
c('ChatUI_HouseOfPytry.ent','ChatUI_HouseOfPytry.tar.gz')
c('ChatUI_HouseOfPytry.ent','ChatUI_HouseOfPytry.gz')
