filename='ChatUI_HouseOfPytry'
kind='ent'
view=[[]]
def lead0(x):
    if len(x)==2:
        return x
    else:
        return '0'+x
def hex2byte(x):
    if len(x)==4:
        return bytes.fromhex(x.lstrip('0x'))
    else:
        match x[-1]:
            case '0':
                return b'\x00'
            case '1':
                return b'\x01'
            case '2':
                return b'\x02'
            case '3':
                return b'\x03'
            case '4':
                return b'\x04'
            case '5':
                return b'\x05'
            case '6':
                return b'\x06'
            case '7':
                return b'\x07'
            case '8':
                return b'\x08'
            case '9':
                return b'\x09'
            case 'A':
                return b'\x0A'
            case 'B':
                return b'\x0B'
            case 'C':
                return b'\x0C'
            case 'D':
                return b'\x0D'
            case 'E':
                return b'\x0E'
            case 'F':
                return b'\x0F'
with open(f'{filename}.{kind}','rb')as f:
    a=f.read()
    #print(a)
    b=[hex(x) for x in a]
    c=[x.replace('0x','') for x in b]
n=1
for x in c:
    if n==20:
        n=0
        view.append([])
    view[-1].append(x)
    n+=1
for x in view:
    for y in x:
        print(lead0(y),end=' ')
    print()
with open(f'{filename}_copy.{kind}','wb')as f:
    for x in b:
        f.write(hex2byte(x))